const { expect } = require("@jest/globals");

test("should first", () => {
  expect(1).toBe(1);
});
